import {Typography } from "@mui/material";

export default function CadastroEstabelecimento() {


    return (
        <>
            <Typography fontFamily={"Poppins"} fontWeight={500} variant="p" fontSize={'24px'} >
                Cadastro de Estabelecimentos
            </Typography>
            
            


        </>
    );
}
