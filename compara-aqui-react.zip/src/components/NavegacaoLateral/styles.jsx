import styled from "styled-components";


export const ContainerNavegacaoLateral = styled('div')(() => ({
    width: 60,
    background: "#BDC0DD",
    height: "100vh",
    display: "inline-flex",
    alignItems: "flex-start",
    flexDirection: "column",
}));